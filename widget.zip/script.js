define([`${localStorage['rsDebugUrl_1lvc0oy8ls93yqrz'] || './build/js/app.ba8acb2d.js'}`], m => {
  return function () {
    return m.default(this)
  }
})
